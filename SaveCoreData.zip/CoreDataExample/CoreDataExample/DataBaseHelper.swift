//
//  DataBaseHelper.swift
//  CoreDataExample
//
//  Created by syed fazal abbas on 12/05/23.
//

import Foundation
import UIKit
import CoreData

class DataBaseHelper{
    
    static let shareInstance = DataBaseHelper()
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func Savedata(collegeDict : [String:String]){
        let data = NSEntityDescription.insertNewObject(forEntityName: "Student", into: context!) as? Student
        data!.studentname = collegeDict["Name"]
        data!.studentfather = collegeDict["Father"]
        data!.studentaddress = collegeDict["Address"]
        do{
            try context?.save()
        }
        catch{
            print("Not Found")
        }
    }
}
